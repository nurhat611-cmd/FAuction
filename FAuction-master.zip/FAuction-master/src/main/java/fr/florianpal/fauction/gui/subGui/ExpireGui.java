package fr.florianpal.fauction.gui.subGui;

import fr.florianpal.fauction.FAuction;
import fr.florianpal.fauction.configurations.gui.ExpireGuiConfig;
import fr.florianpal.fauction.enums.ClaimType;
import fr.florianpal.fauction.enums.SpamAction;
import fr.florianpal.fauction.events.ExpireRemoveEvent;
import fr.florianpal.fauction.gui.AbstractGuiWithAuctions;
import fr.florianpal.fauction.languages.MessageKeys;
import fr.florianpal.fauction.managers.ClaimManager;
import fr.florianpal.fauction.objects.Auction;
import fr.florianpal.fauction.objects.Category;
import fr.florianpal.fauction.objects.Sort;
import fr.florianpal.fauction.utils.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public class ExpireGui extends AbstractGuiWithAuctions {

    private final ExpireGuiConfig expireGuiConfig;

    public ExpireGui(FAuction plugin, Player player, List<Auction> auctions, int page, Category category, Sort sort) {
        super(plugin, player, page, auctions, category, sort, plugin.getConfigurationManager().getExpireConfig());
        this.expireGuiConfig = plugin.getConfigurationManager().getExpireConfig();
    }

    @Override
    protected void previousAction() {
        FAuction.newChain(player).asyncFirst(expireCommandManager::getExpires).syncLast(expires -> {
            ExpireGui gui = new ExpireGui(plugin, player, expires, this.page - 1, category, sort);
            gui.initialize();
        }).execute();
    }

    @Override
    protected void nextAction() {
        FAuction.newChain(player).asyncFirst(expireCommandManager::getExpires).syncLast(expires -> {
            ExpireGui gui = new ExpireGui(plugin, player, expires, this.page + 1, category, sort);
            gui.initialize();
        }).execute();
    }

    @Override
    protected void categoryAction(Category nextCategory) {
        FAuction.newChain(player).asyncFirst(expireCommandManager::getExpires).syncLast(expires -> {
            ExpireGui gui = new ExpireGui(plugin, player, auctions,1 , nextCategory, sort);
            gui.initialize();
        }).execute();
    }

    @Override
    protected void sortingAction(Sort nextSort) {
        FAuction.newChain(player).asyncFirst(auctionCommandManager::getAuctions).syncLast(auctions -> {
            AuctionsGui gui = new AuctionsGui(plugin, player, auctions, 1, category, nextSort);
            gui.initialize();
        }).execute();
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {

        if (e.getInventory() != inv || inv.getHolder() != this || player != e.getWhoClicked()) {
            return;
        }
        e.setCancelled(true);

        ItemStack clickedItem = e.getCurrentItem();
        if (clickedItem == null || clickedItem.getType() == Material.AIR) return;

        if (guiClick(e)) {
            return;
        }

        if (spamManager.spamTest(player, SpamAction.INTERACT)) {
            return;
        }

        for (var index : expireGuiConfig.getBaseBlocks().entrySet()) {
            if (index.getValue() == e.getRawSlot()) {

                if (auctions.isEmpty()) {
                    player.closeInventory();
                    return;
                }

                int itemIndex = ((index.getKey() + 1) + (this.expireGuiConfig.getBaseBlocks().size() * (this.page - 1))) - 1;
                Auction auction = auctions.get(itemIndex);

                if (e.isLeftClick()) {

                    int expireId = auction.getId();

                    // Reserved on the main thread : every other click of the same tick stops here,
                    // before being able to schedule a second chain on the same item.
                    long expireClaim = plugin.getClaimManager().tryClaim(ClaimType.EXPIRE, expireId);
                    if (expireClaim == ClaimManager.NOT_CLAIMED) {
                        return;
                    }

                    if (!auction.getPlayerUUID().equals(player.getUniqueId())) {
                        plugin.getClaimManager().release(ClaimType.EXPIRE, expireId, expireClaim);
                        return;
                    }

                    FAuction.newChain(player).asyncFirst(() -> expireCommandManager.claim(expireId)).syncLast(a -> {

                        // The row is already gone : nothing can be handed over twice from here.
                        if (a == null) {
                            return;
                        }

                        if (player.getInventory().firstEmpty() == -1) {
                            player.getWorld().dropItem(player.getLocation(), a.getItemStack());
                        } else {
                            player.getInventory().addItem(a.getItemStack());
                        }

                        auctions.remove(auction);
                        Bukkit.getPluginManager().callEvent(new ExpireRemoveEvent(player, a));

                        MessageUtil.sendMessage(plugin, player, MessageKeys.REMOVE_EXPIRE_SUCCESS);

                        FAuction.newChain(player).asyncFirst(() -> expireCommandManager.getExpires(player.getUniqueId())).syncLast(expires -> {
                            ExpireGui gui = new ExpireGui(plugin, player, expires, 1, category, sort);
                            gui.initialize();
                        }).execute();
                    }, a -> {
                        // The player left before the item could be handed over : the row is already
                        // gone, so put it back in their expired items rather than destroying it.
                        // There is no restore() here, addExpire() re-inserting the row under the id
                        // the database assigns is the same thing.
                        if (a == null) {
                            return;
                        }
                        if (!expireCommandManager.addExpire(a)) {
                            plugin.getLogger().severe("Expired item " + a.getId() + " of " + a.getPlayerName() + " could not be put back after " + player.getName() + " left before it could be handed over ; the item is lost.");
                            return;
                        }
                        plugin.getLogger().severe("Expired item " + a.getId() + " of " + a.getPlayerName() + " was claimed by " + player.getName() + ", who left before the item could be handed over ; put back in their expired items instead of being lost.");
                    }).execute(() -> plugin.getClaimManager().release(ClaimType.EXPIRE, expireId, expireClaim));
                }
            }
        }
    }
}